struct Libros {
    char *titulo;
    char  *autor;
    char  *anio;
    char  *estante_numero;
    char   *estante_seccion;
    char   *edificio;
    char   *piso;
    char   *sede;
    int borrar;
} ;

// aca defino que el conjunto "struct Libros"
// será un nuevo tipo de datos conocido ahora
// conocido como Libro
typedef struct Libros Libro;

//habiendo creado el tipo de dato,
// defino un puntero a una coleccion de libros;
Libro *libros;

//uso la palabra clave extern para poder acceder
//desde afuera
extern int registryCount;

//operaciones con archivos
Libro* getlibritos(FILE *fp);
void writeLibros(Libro *libros, FILE *fp);

//otras operaciones
//contratos
void mostrarLibros();
void eliminarLibro();
void agregarLibro();
void eliminarSede();
void eliminarSeccion();
void eliminarPiso();
void agregarSede();
void agregarSeccion();
void agregarPiso();
void editarLibro();